package com.off;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication//springboot核心注解，用于标识启动类
@ComponentScan(basePackages = "com.off")
//扫描DAO层接口
@ComponentScan("com.off.dao")

public class DemoApplication {

    public static void main(String[] args) {

        SpringApplication.run(DemoApplication.class, args);
    }

}
