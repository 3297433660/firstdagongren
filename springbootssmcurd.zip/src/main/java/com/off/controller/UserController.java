package com.off.controller;

import com.off.entity.User;
import com.off.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class UserController {

    @Autowired
    public UserService userService;
    //添加用户
    @RequestMapping("/pa")
    @ResponseBody
    public String insertUserWithParam(User user){
        int i = userService.insertUserWithParam(user);
        if(i>0){
            return "成功";
        }
        return "失败";
    }


    //更新用户
    @RequestMapping("/updataUser")
    @ResponseBody
    public String updataUser(User user){
        int i = userService.updataUser(user);
        if(i>0){
            return "成功";
        }
        return "失败";
    }

    //删除用户
    @RequestMapping("/deleteUser")
    @ResponseBody
    public String deleteUser(@RequestParam("id") int id){
        int i = userService.deleteUser(id);
        if(i>0){
            return "成功";
        }
        return "失败";
    }

    //查询用户 根据ID
    @RequestMapping("/selectUserById")
    @ResponseBody
    public User selectUserById(@RequestParam("id")int id){
        User user = userService.selectUserById(1);
        System.out.println(user);
        return user;
    }

    @RequestMapping("/selectAllUser")
    @ResponseBody
    //查询所有用户
    public List<User> selectAllUser(){
        List<User> users = userService.selectAllUser();
        return users;
    }

}
