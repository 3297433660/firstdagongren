package com.off.service;

import com.off.entity.User;

import java.util.List;

public interface UserService {
    //添加 用户
    public int insertUserWithParam(User user);
    //更新用户
    public int updataUser(User user);
    //根据ID 删除用户
    public int deleteUser(int id);
    //根据ID 查询用户
    public User selectUserById(int id);
    //查询所有用户
    public List<User> selectAllUser();
}
