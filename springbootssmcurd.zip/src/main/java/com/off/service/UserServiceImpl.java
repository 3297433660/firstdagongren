package com.off.service;

import com.off.dao.UserDao;
import com.off.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    public UserDao userDao;


    public int insertUserWithParam(User user) {
        return userDao.insertUserWithParam(user);
    }

    public int updataUser(User user) {
        return userDao.updataUser(user);
    }

    public int deleteUser(int id) {
        return userDao.deleteUser(id);
    }

    public User selectUserById(int id) {
        return userDao.selectUserById(id);
    }

    public List<User> selectAllUser() {
        return userDao.selectAllUser();
    }
}
